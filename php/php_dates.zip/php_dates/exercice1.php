<?php
/* --------------------------------------------------------
* PHP Phase 6 Dates et heures
*
* Exercice 1
*
* Affichez la date du jour au format _mardi 2 juillet 2019_. 
* ---------------------------------------------------------- */

$oDate = new DateTime();

// Numéro du jour, sans 0 initial
$j = $oDate->format("j");

// numéro du jour de la semaine (1 => lundi, ...., 7 => dimanche)
$nj = $oDate->format('N');

// Numéro du mois, sans 0 initial
$m = $oDate->format("n");
// ==> source php.net https://www.php.net/manual/fr/class.datetime.php

$aJours = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"];

// Attention, 1 à 12, donc un vide au début pour la position 0
$aMois = ["", "janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre", "novembre", "décembre"];
var_dump($j);
echo $aJours[$nj] . " " . $oDate->format("j") . " " . $aMois[$m] . " " . $oDate->format("Y");